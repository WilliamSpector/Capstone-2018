# Capstone-2018
## Fonts
Please install included fonts. On MacOS (OSX) copy all .ttf files to /Library/fonts which can be found by going to terminal and keying in open /Library/fonts or open the file with Font Book and click install.
## Opening the Presentation
Open Capstone.key if Keynote is installed or Capstone.pptx if not. Capstone.pptx can be imported to Google Slides but the music won't work and neither will all the fonts, even after previous step is followed.
